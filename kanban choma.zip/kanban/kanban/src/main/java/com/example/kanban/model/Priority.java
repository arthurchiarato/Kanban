package com.example.kanban.model;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}

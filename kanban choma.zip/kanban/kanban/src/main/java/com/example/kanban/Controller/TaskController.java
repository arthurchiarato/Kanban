package com.example.kanban.Controller;

import com.example.kanban.model.Task;
import com.example.kanban.Service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping
    public Task createTask(@RequestBody Task task) {
        return taskService.createTask(task);
    }

    @GetMapping
    public Map<String, List<Task>> getAllTasks() {
        List<Task> tasks = taskService.getAllTasks();
        return tasks.stream()
                .collect(Collectors.groupingBy(task -> task.getStatus().name()));
    }

    @PutMapping("/{id}")
    public Task updateTask(@PathVariable Long id, @RequestBody Task taskDetails) {
        return taskService.updateTask(id, taskDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
    }

    @PutMapping("/{id}/move")
    public Task moveTask(@PathVariable Long id) {
        return taskService.moveTask(id);
    }

    // Novo endpoint para filtrar tarefas por prioridade
    @GetMapping("/filter")
    public List<Task> filterTasks(@RequestParam(required = false) String priority,
                                  @RequestParam(required = false) LocalDate dueDate) {
        return taskService.filterTasks(priority, dueDate);
    }

    // Novo endpoint para gerar relatório de tarefas
    @GetMapping("/report")
    public Map<String, List<Task>> generateReport() {
        List<Task> tasks = taskService.getAllTasks();
        return tasks.stream()
                .collect(Collectors.groupingBy(task -> {
                    if (task.getDueDate() != null && task.getDueDate().isBefore(LocalDate.now()) && !task.getStatus().equals(Status.DONE)) {
                        return "Atrasadas";
                    }
                    return task.getStatus().name();
                }));
    }
}
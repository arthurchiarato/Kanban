package com.example.kanban.model;

public enum Status {
    TODO,
    IN_PROGRESS,
    DONE
}
